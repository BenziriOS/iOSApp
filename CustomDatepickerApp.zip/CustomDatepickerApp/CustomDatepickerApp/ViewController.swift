//
//  ViewController.swift
//  CustomDatepickerApp
//
//  Created by Jahangir Bavra on 12/04/23.
//

import UIKit
import MDatePickerView

class ViewController: UIViewController {

    @IBOutlet weak var lbl_date: UILabel!
    var MDate : MDatePickerView = {
             let mdate = MDatePickerView()
             mdate.Color = .gray
             mdate.delegate = self as! any MDatePickerViewDelegate
             mdate.from = 1980
             mdate.to = 2100
             return mdate
         }()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(MDate)
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_opendatepicker(_ sender: Any)
    {
        
    }
    
}
extension ViewController : MDatePickerViewDelegate {
    func mdatePickerView(selectDate: Date) {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy - MM - dd"
        let date = formatter.string(from: selectDate)
        lbl_date.text = date
    }
}
