//
//  ViewController.swift
//  ImageSlideshowApp
//
//  Created by Jahangir Bavra on 12/04/23.
//

import UIKit


class ViewController: UIViewController,KASlideShowDelegate {

    @IBOutlet weak var slideShow: KASlideShow!
    override func viewDidLoad() {
        super.viewDidLoad()
        createSlideshow()
        // Do any additional setup after loading the view.
    }

    func createSlideshow()
    {
        slideShow.delegate = self
        slideShow.delay = 2 // Delay between transitions
        slideShow.transitionDuration = 0.5 // Transition duration
        slideShow.transitionType = KASlideShowTransitionType.slide // Choose a transition type (fade or slide)
        slideShow.imagesContentMode = .scaleAspectFit // Choose a content mode for images to display
        slideShow.addImages(fromResources: ["01.png","02.png","03.png","04.png"]) // Add images from resources
        slideShow.add(KASlideShowGestureType.tap) // Gesture to go previous/next directly on the image (Tap or Swipe)
        slideShow.start()
    }
    

}

