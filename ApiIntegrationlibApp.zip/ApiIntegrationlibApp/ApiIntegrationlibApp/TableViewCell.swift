//
//  TableViewCell.swift
//  ApiIntegrationlibApp
//
//  Created by MAC03 on 08/02/23.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var flag_img: UIImageView!
    @IBOutlet weak var lbl_cnt: UILabel!
    @IBOutlet weak var lbl_capital: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
