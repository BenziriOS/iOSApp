//
//  ViewController.swift
//  ApiIntegrationlibApp
//
//  Created by MAC03 on 06/02/23.
//

import UIKit
import Alamofire
import SwiftyJSON
import Kingfisher

struct apidata {
    var name:String?
    var capital:String?
    var flags:String?
    var currencies:String?
}
struct currenciesdata:Decodable
{
    var code:String?
    var name:String?
    var symbol:String?
}


class ViewController: UIViewController {

    var finaldata=[apidata]()
    var cdata=[currenciesdata]()
    
    var dict=Dictionary<String,Any>()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        restcountries()
        // Do any additional setup after loading the view.
    }


    func restcountries()
    {
        let url=URL(string: "https://restcountries.com/v2/all")
        do
        {
            let dt=try Data(contentsOf: url!)
            let json = try! JSON(data: dt)
    
            let arrayCount = json.array?.count ?? 0
            
            for i in 0..<arrayCount {
                // ID
                let nm = json[i]["name"].string ?? "N/A"
                //print("Name: \(nm)")
                
                let capital = json[i]["capital"].string ?? "N/A"
                //print("Capital: \(capital)")
                
                let flag = json[i]["flags"]["png"].string ?? "N/A"
                //print("Falg: \(flag)")
                
                //let currencies = json[i]["currencies"].arrayObject
                //print(currencies ?? "N/A")
                finaldata.append(apidata(name: nm, capital: capital, flags: flag))
              
                    for c in json[i]["currencies"].arrayValue
                    {
                        let nm=c["name"].stringValue
                        let code=c["code"].stringValue
                        let sym=c["symbol"].stringValue
                        DispatchQueue.main.async {
                            self.cdata.append(currenciesdata(code: code, name: nm, symbol: sym))
                            print(self.cdata)
                        }
                        
                        
                    }
                
                
            }

        }
        catch
        {
            print(error.localizedDescription)
        }
        
        
    }
}

extension ViewController:UITableViewDataSource,UITableViewDelegate
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return finaldata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell=TableViewCell()
        cell=tableView.dequeueReusableCell(withIdentifier: "cell") as! TableViewCell
        cell.lbl_cnt.text=finaldata[indexPath.row].name
        cell.lbl_capital.text=finaldata[indexPath.row].capital
        let url=URL(string: finaldata[indexPath.row].flags!)
        cell.flag_img.kf.setImage(with: url)
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailVC=storyboard?.instantiateViewController(identifier: "detailVC") as! DetailViewController
       
            detailVC.m_code=cdata[indexPath.row].code!
            detailVC.m_name=cdata[indexPath.row].name!
            detailVC.m_symbol=cdata[indexPath.row].symbol!
            detailVC.m_cname=finaldata[indexPath.row].name!
       
        navigationController?.pushViewController(detailVC, animated: true)
    }
    
    
}
