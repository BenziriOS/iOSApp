//
//  DetailViewController.swift
//  ApiIntegrationlibApp
//
//  Created by MAC03 on 08/02/23.
//

import UIKit

class DetailViewController: UIViewController {

    @IBOutlet weak var dt_img: UIImageView!
    @IBOutlet weak var dt_cnName: UILabel!
    @IBOutlet weak var lbl_code: UILabel!
    @IBOutlet weak var lbl_name: UILabel!
    @IBOutlet weak var lbl_symbol: UILabel!
    
    //var m_img=UIImage()
    var m_cname=""
    var m_code=""
    var m_name=""
    var m_symbol=""
    override func viewDidLoad() {
        super.viewDidLoad()

        //dt_img.image=m_img
       
            dt_cnName.text=m_cname
            lbl_code.text=m_code
            lbl_name.text=m_name
            lbl_symbol.text=m_symbol
        
        
    }
    

}
