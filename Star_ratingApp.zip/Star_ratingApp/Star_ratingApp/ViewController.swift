//
//  ViewController.swift
//  Star_ratingApp
//
//  Created by Jahangir Bavra on 13/04/23.
//

import UIKit
import SwiftyStarRatingView

class ViewController: UIViewController {

    @IBOutlet weak var mystartview: SwiftyStarRatingView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

