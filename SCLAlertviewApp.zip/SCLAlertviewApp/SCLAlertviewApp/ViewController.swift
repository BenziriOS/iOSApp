//
//  ViewController.swift
//  SCLAlertviewApp
//
//  Created by Jahangir Bavra on 12/04/23.
//

import UIKit
import SCLAlertView

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn_alert(_ sender: Any)
    {
        
        //SCLAlertView().showError("Hello Error", subTitle: "This is a more descriptive error text.") // Error
        //SCLAlertView().showNotice("Hello Notice", subTitle: "This is a more descriptive notice text.") // Notice
        //SCLAlertView().showWarning("Hello Warning", subTitle: "This is a more descriptive warning text.") // Warning
        //SCLAlertView().showInfo("Hello Info", subTitle: "This is a more descriptive info text.") // Info
        //SCLAlertView().showEdit("Hello Edit", subTitle: "This is a more descriptive info text.") // Edit
        
        var errorAlert=SCLAlertView()
        let appearance = SCLAlertView.SCLAppearance(
            showCircularIcon: true
        )
        errorAlert = SCLAlertView(appearance: appearance)
        let alertViewIcon = UIImage(named: "icon")
        errorAlert.addButton("More") {
            
            print("More button clicked!")
        }
        errorAlert.showSuccess("Success", subTitle: "Signup Successfully!", circleIconImage:alertViewIcon)
    }
    
}

