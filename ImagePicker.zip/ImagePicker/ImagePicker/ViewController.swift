//
//  ViewController.swift
//  ImagePicker
//
//  Created by Jahangir Bavra on 19/04/23.
//

import UIKit
import OpalImagePicker

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func btn_photo(_ sender: Any)
    {
        let openPhoto=OpalImagePickerController()
        present(openPhoto, animated: true)
    }
}

