//
//  ViewController.swift
//  DropdownApp
//
//  Created by Jahangir Bavra on 12/04/23.
//

import UIKit
import iOSDropDown

class ViewController: UIViewController {

    @IBOutlet weak var city_textfield: DropDown!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        city_textfield.optionArray=["Ahmedabad","Rajkot","Baroda","Surat","Jamnagar","Navsari"]
        // Do any additional setup after loading the view.
    }


}

