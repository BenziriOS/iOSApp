//
//  ViewController.swift
//  Alamofire_SwiftyJSON_Kingfisher
//
//  Created by mr.jb on 24/05/23.
//

import UIKit
import Alamofire
import SwiftyJSON
import Kingfisher
import SystemConfiguration

/*struct APIModel {
    var state : String? = ""
    var statecode : String? = ""
    var  active : Int? = 0
    
    init(myJSON : JSON)
    {
        active = myJSON["active"].intValue
        state = myJSON["state"].stringValue
        statecode = myJSON["statecode"].stringValue
    }
} */

struct RestData {
    var name : String? = ""
    var capital : String? = ""
    var flags : String? = ""
    
    
}

class ViewController: UIViewController {
//var arraData  = [APIModel]()
    var arrData = [RestData]()
    @IBOutlet var mytable: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        APIREquest()
        NetworkManager()
        NetworkManager.shared.startNetworkReachabilityObserver()
    }

    func APIREquest() {
        //let url = URL(string: "https://data.covid19india.org/data.json")
        
        let url = URL(string: "https://restcountries.com/v2/all")
//        let request = AF.request("https://data.covid19india.org/data.json")
//        request.responseJSON{(data) in
//            //print(data)
//        }
        URLSession.shared.dataTask(with: url!){ [self] (data , response , error) in
            
            do {
                let dt = try Data(contentsOf: url!)
                 let json = try!  JSON(data: data!)
            
/* DATA in Dictionary        for item in json["statewise"].arrayValue
                    {
                        self.arraData.append(APIModel(myJSON: item))
                    } */
                    
// Data in ArrayFormate
                    /*for item in json.arrayValue{
                        self.arrData.append(RestData(myJSON: item))
                    } */
                let arrayCount = json.array?.count ?? 0
                
                for i in 0..<arrayCount{
                    
                    let nm = json[i]["name"].string ?? "INDIA"
                    print(nm)
                    
                    let cap = json[i]["capital"].string ?? "DELHI"
                    print(cap)
                    
                    let flg = json[i]["flags"]["png"].string ?? "nil"
                    print(flg)
                    
                    self.arrData.append(RestData( name : nm , capital: cap , flags: flg))
                }
                    DispatchQueue.main.async {
                       // print(self.arraData)
                        self.mytable.reloadData()
                    }
            
            }
            catch
            {
                print(String(describing: error))
            }
            
        }.resume()
       
        
    }
}

class NetworkManager {
    static let shared = NetworkManager()
    let reachabilityManager = Alamofire.NetworkReachabilityManager(host: "www.apple.com")
    func startNetworkReachabilityObserver() {
        reachabilityManager?.startListening(onUpdatePerforming: { status in

            switch status {
                            case .notReachable:
                                print("The network is not reachable")
                            case .unknown :
                                print("It is unknown whether the network is reachable")
                            case .reachable(.ethernetOrWiFi):
                                print("The network is reachable over the WiFi connection")
                            case .reachable(.cellular):
                                print("The network is reachable over the cellular connection")
                      }
        })
    }
}

extension ViewController : UITableViewDelegate , UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        cell.textLabel?.text = self.arrData[indexPath.row].name
        cell.detailTextLabel?.text = self.arrData[indexPath.row].capital
        let imagurl = URL(string: arrData[indexPath.row].flags!)
        cell.imageView?.kf.setImage(with: imagurl)
        return cell
    }
    
    
}
