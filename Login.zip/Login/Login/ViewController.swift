//
//  ViewController.swift
//  Login
//
//  Created by Jahangir Bavra on 28/04/23.
//

import UIKit
import CoreData
import FacebookCore
import FacebookLogin

class MainViewController: UIViewController {
        
        @IBOutlet weak var facebookButton: UIButton!
        @IBOutlet weak var usernameTextField: UITextField!
        @IBOutlet weak var passwordTextField: UITextField!
        @IBOutlet weak var emailTextField: UITextField!
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            facebookButton.addTarget(self, action: #selector(loginWithFacebook), for: .touchUpInside)
        }
        
        @objc func loginWithFacebook() {
            let loginManager = LoginManager()
            loginManager.logIn(permissions: [.publicProfile, .email], viewController: self) { (result) in
                switch result {
                case .cancelled:
                    print("Login cancelled")
                case .failed(let error):
                    print("Login failed with error: \(error.localizedDescription)")
                case .success(_, _, let accessToken):
                    print("Login successful with access token: \(accessToken.tokenString)")
                    self.fetchFacebookUserData(accessToken: accessToken)
                }
            }
        }
        
        func fetchFacebookUserData(accessToken: AccessToken) {
            let graphRequest = GraphRequest(graphPath: "me", parameters: ["fields": "id, name, email"])
            
            graphRequest.start { (urlResponse, requestResult) in
                switch requestResult {
                    
                case .success(let graphResponse):
                    if let responseDictionary = graphResponse.dictionaryValue {
                        if let username = responseDictionary["name"] as? String,
                           let email = responseDictionary["email"] as? String {
                            self.saveUser(username: username, password: "", email: email)
                            self.navigateToMainPage()
                        }
                    }
                case .failed(let error):
                    print("Error fetching Facebook user data: \(error.localizedDescription)")
                }
            }
        }
        
        func saveUser(username: String, password: String, email: String) {
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }
            let context = appDelegate.persistentContainer.viewContext
            let entity = NSEntityDescription.entity(forEntityName: "User", in: context)!
            let user = NSManagedObject(entity: entity, insertInto: context)
            user.setValue(username, forKeyPath: "username")
            user.setValue(password, forKeyPath: "password")
            user.setValue(email, forKeyPath: "email")
            do {
                try context.save()
            } catch let error as NSError {
                print("Could not save user. \(error), \(error.userInfo)")
            }
        }
        
        func navigateToMainPage() {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let mainViewController = storyboard.instantiateViewController(withIdentifier: "MainViewController")
            UIApplication.shared.windows.first?.rootViewController = mainViewController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
        }
    }

