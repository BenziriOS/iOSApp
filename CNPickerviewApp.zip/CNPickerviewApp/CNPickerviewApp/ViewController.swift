//
//  ViewController.swift
//  CNPickerviewApp
//
//  Created by Jahangir Bavra on 14/04/23.
//

import UIKit
import CountryPickerView

class ViewController: UIViewController {

    @IBOutlet weak var myCNPicker: CountryPickerView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

