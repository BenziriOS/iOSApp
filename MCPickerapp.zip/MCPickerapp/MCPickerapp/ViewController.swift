//
//  ViewController.swift
//  MCPickerapp
//
//  Created by Jahangir Bavra on 12/04/23.
//

import UIKit
import McPicker

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func btn_barpopover(_ sender: UIBarButtonItem)
    {
        //Popover Picker
        let data: [[String]] = [["Kevin", "Lauren", "Kibby", "Stella"]]
        McPicker.showAsPopover(data: data, fromViewController: self, barButtonItem:sender) { [weak self] (selections: [Int : String]) -> Void in
            if let name = selections[0] {
                //self?.label.text = name
                print(name)
            }
        }
    }
    
    
    @IBAction func btn_pickres(_ sender: UIButton)
    {
        /*McPicker.show(data: [["Rajkot", "Ahmedabad", "Surat", "Jamnagar"]]) {  [weak self] (selections: [Int : String]) -> Void in
         if let name = selections[0] {
         //self?.label.text = name
         }
         }
        */
        
        
        
    }
        
}

