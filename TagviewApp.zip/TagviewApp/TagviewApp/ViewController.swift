//
//  ViewController.swift
//  TagviewApp
//
//  Created by Jahangir Bavra on 19/04/23.
//

import UIKit
import TagListView

class ViewController: UIViewController
{
    @IBOutlet weak var tagview: TagListView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tagSetup()
        tagview.delegate=self
    }
    
    func tagSetup()
    {
        tagview.textFont = UIFont.systemFont(ofSize: 30)
        tagview.alignment = .center // possible values are [.leading, .trailing, .left, .center, .right]
        //tagview.minWidth = 57

        //tagview.addTag("TagListView")
        tagview.addTags(["iOS","Android","Python","PHP","JAVA","Flutter","React"])

        tagview.selectedTextColor = .red
        //tagview.insertTag("This should be the second tag", at: 1)

        //tagview.setTitle("New Title", at: 6) // to replace the title a tag

        //tagview.removeTag("meow") // all tags with title “meow” will be removed
        //tagview.removeAllTags()
    }


}
extension ViewController:TagListViewDelegate
{
    func tagPressed(_ title: String, tagView: TagView, sender: TagListView)
    {
        print("Tag pressed: \(title)")
    }
}
